import java.util.*;

// Enum para las funciones del robot
enum TipoFuncion {
    CONSTRUCCION,
    VIGILANCIA,
    ASISTENCIA,
    EXPLORACION
}

// Clase Robot
class Robot {
    private int id;
    private String modelo;
    private int bateriaPorcentaje;
    private TipoFuncion funcion;

    // Constructor
    public Robot(int id, String modelo, int bateriaPorcentaje, TipoFuncion funcion) {
        this.id = id;
        this.modelo = modelo;
        this.bateriaPorcentaje = bateriaPorcentaje;
        this.funcion = funcion;
    }

    // Getters y Setters
    public int getId() { return id; }
    public String getModelo() { return modelo; }
    public void setModelo(String modelo) { this.modelo = modelo; }

    public int getBateriaPorcentaje() { return bateriaPorcentaje; }
    public void setBateriaPorcentaje(int bateriaPorcentaje) {
        if (bateriaPorcentaje >= 0 && bateriaPorcentaje <= 100) {
            this.bateriaPorcentaje = bateriaPorcentaje;
        }
    }

    public TipoFuncion getFuncion() { return funcion; }
    public void setFuncion(TipoFuncion funcion) { this.funcion = funcion; }

    // Metodo para mostrar info
    public void mostrarInfo() {
        System.out.println("ID: " + id + " | Modelo: " + modelo + " | Bateria: " + bateriaPorcentaje + "% | Funcion: " + funcion);
    }

    // Metodo para simular trabajo
    public void trabajar() {
        int consumo = 0;
        switch (funcion) {
            case CONSTRUCCION: consumo = 50; break;
            case VIGILANCIA: consumo = 10; break;
            case ASISTENCIA: consumo = 20; break;
            case EXPLORACION: consumo = 30; break;
        }
        if (bateriaPorcentaje >= consumo) {
            bateriaPorcentaje -= consumo;
            System.out.println("Robot " + modelo + " esta realizando " + funcion + ". Se resto " + consumo + "% de su bateria.");
        } else {
            System.out.println("Robot " + modelo + " no tiene suficiente bateria para realizar " + funcion + ". Requiere recarga.");
        }
    }
}

// Clase principal
public class ControlCentral {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random rand = new Random();

        // Crear arreglo de 10 robots
        Robot[] robots = new Robot[10];
        for (int i = 0; i < 10; i++) {
            int id = i + 1;
            char letra = (char) ('A' + rand.nextInt(26));
            int numero = rand.nextInt(9) + 1;
            String modelo = "Omega-" + letra + numero;
            int bateria = rand.nextInt(86) + 5; // entre 5 y 90
            TipoFuncion funcion = TipoFuncion.values()[rand.nextInt(4)];
            robots[i] = new Robot(id, modelo, bateria, funcion);
        }

        // Menu principal
        int opcion;
        do {
            System.out.println("\n--- MENU PRINCIPAL ---");
            System.out.println("1. Editar robot");
            System.out.println("2. Mostrar robots");
            System.out.println("3. Recargar robots");
            System.out.println("4. Simular trabajo");
            System.out.println("5. Salir");
            System.out.print("Seleccione opcion: ");
            opcion = sc.nextInt();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese ID del robot: ");
                    int idBuscar = sc.nextInt();
                    if (idBuscar >= 1 && idBuscar <= 10) {
                        Robot r = robots[idBuscar - 1];
                        System.out.print("Nuevo modelo: ");
                        String nuevoModelo = sc.next();
                        r.setModelo(nuevoModelo);

                        System.out.print("Nueva bateria (0-100): ");
                        int nuevaBateria = sc.nextInt();
                        r.setBateriaPorcentaje(nuevaBateria);

                        System.out.println("Seleccione funcion: 0-CONSTRUCCION, 1-VIGILANCIA, 2-ASISTENCIA, 3-EXPLORACION");
                        int f = sc.nextInt();
                        r.setFuncion(TipoFuncion.values()[f]);
                    } else {
                        System.out.println("Robot no encontrado.");
                    }
                    break;

                case 2:
                    for (Robot r : robots) {
                        r.mostrarInfo();
                    }
                    break;

                case 3:
                    for (Robot r : robots) {
                        if (r.getBateriaPorcentaje() < 50) {
                            int recarga = rand.nextInt(21) + 10; // entre 10 y 30
                            r.setBateriaPorcentaje(Math.min(100, r.getBateriaPorcentaje() + recarga));
                            System.out.println("Robot " + r.getModelo() + " recargado +" + recarga + "%.");
                        }
                    }
                    break;

                case 4:
                    for (Robot r : robots) {
                        r.trabajar();
                    }
                    break;

                case 5:
                    System.out.println("Saliendo del sistema...");
                    break;

                default:
                    System.out.println("Opcion invalida.");
            }
        } while (opcion != 5);

        sc.close();
    }
}

